<?php
/**
 * [WeEngine System] Copyright (c) 2013 WE7.CC
 */
defined('IN_IA') or exit('Access Denied');

class FujinModule extends WeModule {
	public function fieldsFormDisplay() {
		return true;
	}
}
