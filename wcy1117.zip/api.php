<?php
/**
 * 接口文件
 * 
 * [WeEngine System] Copyright (c) 2013 WE7.CC
 */
define('IN_API', true);
require 'source/bootstrap.inc.php';

$engine = new WeEngine();
$engine->start();
