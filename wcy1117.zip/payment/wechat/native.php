<?php
/**
 * [WeEngine System] Copyright (c) 2013 WE7.CC
 * $sn: htdocs/payment/wechat/native.php : v 325146c16ab5 : 2014/04/17 07:24:45 : RenChao $
 */
define('IN_MOBILE', true);
require '../../source/bootstrap.inc.php';
message('支付失败, 请稍后重试.');
