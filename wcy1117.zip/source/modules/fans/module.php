<?php
/**
 * 粉丝管理模块定义
 *
 * @author WeEngine Team
 */
defined('IN_IA') or exit('Access Denied');

class FansModule extends WeModule {

}
