<?php 
/**
 * 图标选择
 * [WeEngine System] Copyright (c) 2013 WE7.CC
 */
defined('IN_IA') or exit('Access Denied');
template('site/icon');